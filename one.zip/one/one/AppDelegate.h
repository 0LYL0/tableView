//
//  AppDelegate.h
//  one
//
//  Created by  刘雅兰 on 17/10/23.
//  Copyright © 2017年  刘雅兰. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

