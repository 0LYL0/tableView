//
//  DataModel.h
//  one
//
//  Created by  刘雅兰 on 17/10/23.
//  Copyright © 2017年  刘雅兰. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DataModel : NSObject
@property (strong ,nonatomic) NSString *titleLeft;
@property (strong,nonatomic) NSString *titleRight;
@property (strong,nonatomic) NSString *timeBegin;
@property (strong,nonatomic) NSString *timeFinish;
@property (strong,nonatomic) NSString *mainLabel;
@property (strong,nonatomic) NSString *buttonLeft;
@property (strong,nonatomic) NSString *buttonRight;
-(instancetype)initWithDictionary:(NSDictionary *)dict;

@end
