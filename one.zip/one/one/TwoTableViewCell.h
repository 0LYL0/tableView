//
//  TwoTableViewCell.h
//  one
//
//  Created by  刘雅兰 on 17/10/23.
//  Copyright © 2017年  刘雅兰. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TwoTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *titleLeft;
@property (weak, nonatomic) IBOutlet UILabel *timeBegin;
@property (weak, nonatomic) IBOutlet UILabel *timeFinish;
@property (weak, nonatomic) IBOutlet UILabel *titleRight;
@property (weak, nonatomic) IBOutlet UILabel *mainLabel;

@property (weak, nonatomic) IBOutlet UIButton *buttonLeft;

@property (weak, nonatomic) IBOutlet UIButton *buttonRight;

@property (weak, nonatomic) IBOutlet UIView *mainView;

@end
