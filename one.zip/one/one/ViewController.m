//
//  ViewController.m
//  one
//
//  Created by  刘雅兰 on 17/10/23.
//  Copyright © 2017年  刘雅兰. All rights reserved.
//M = Model 数据管理模型
//V 
//C
#import "ViewController.h"
//#import "TableViewCell.h"
#import "TwoTableViewCell.h"
#import "DataModel.h"
#define CellIdentifier @"CellIdentifier"

@interface ViewController ()<UITableViewDelegate, UITableViewDataSource>
//{
//   NSMutableArray *dataArray;
//}

@property(strong,nonatomic) NSArray *shuju;

@property(strong,nonatomic) UITableView *tableView;
@property (strong, nonatomic) NSMutableArray *dataArray;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSBundle *bundle=[NSBundle mainBundle];
    NSString *plistPath=[bundle pathForResource:@"shuju" ofType:@"plist"];
    
    self.shuju=[[NSArray alloc]initWithContentsOfFile:plistPath];
    
    
    _dataArray  = [NSMutableArray new];
    for (NSDictionary *dict in self.shuju) {
        DataModel *model = [[DataModel alloc] initWithDictionary:dict];
        [_dataArray addObject:model];
    }
    
    
    self.tableView=[[UITableView alloc]initWithFrame:self.view.frame style:UITableViewStylePlain];
    
      self.tableView.delegate=self;
    
       self.tableView.dataSource=self;
    
    [_tableView registerNib:[UINib nibWithNibName:@"TwoTableViewCell" bundle:nil] forCellReuseIdentifier:CellIdentifier];
      [self.view addSubview:self.tableView];
    
    _tableView.estimatedRowHeight = 200;
    _tableView.rowHeight = UITableViewAutomaticDimension;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _dataArray.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    TwoTableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
//    if (cell==nil) {
//        cell=[[TwoTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
//    }
    /*
    NSUInteger row=[indexPath row];
    
    NSDictionary *rowDict=self.shuju[row];
    cell.titleLeft.text=rowDict[@"titleLeft"];
    cell.titleRight.text=rowDict[@"titleRight"];
    cell.timeBegin.text=rowDict[@"timeBegin"];
    cell.timeFinish.text=rowDict[@"timeFinish"];
    */
    
    
    DataModel *model=_dataArray[indexPath.row];
    
    cell.titleLeft.text=model.titleLeft;
    cell.titleRight.text=model.titleRight;
    cell.timeBegin.text=model.timeBegin;
    cell.timeFinish.text=model.timeFinish;
    
    cell.buttonLeft.layer.cornerRadius=8;
    cell.buttonLeft.layer.masksToBounds=YES;
    [cell.buttonLeft.layer setBorderColor:[UIColor orangeColor].CGColor];
    [cell.buttonLeft.layer setBorderWidth:1];
    [cell.buttonLeft.layer setMasksToBounds:YES];
    [cell.buttonLeft setTitle:model.buttonLeft forState:UIControlStateNormal];
    
    
    
    if (indexPath.row == 2) {
       // [cell.buttonRight.layer setBackgroundColor:[UIColor whiteColor].CGColor];
        cell.buttonRight.hidden = 1;
    }else{
    
    
    //设置button的边框和边框颜色
    
    cell.buttonRight.layer.cornerRadius=8;
    cell.buttonRight.layer.masksToBounds=YES;
    [cell.buttonRight.layer setBorderColor:[UIColor orangeColor].CGColor];
    
    //设置button边缘的圆角和button上的字
    [cell.buttonRight.layer setBorderWidth:1];
    [cell.buttonRight.layer setMasksToBounds:YES];
    [cell.buttonRight setTitle:model.buttonRight forState:UIControlStateNormal];
    
    }
    
    
    
    
    
    
    
    
    
    
    cell.mainView.layer.cornerRadius=8;
    cell.mainView.layer.masksToBounds=YES;
  //  [cell.mainView.layer setBorderColor:[UIColor blueColor].CGColor];
    [cell.mainView.layer setBorderWidth:1];
    [cell.mainView.layer setMasksToBounds:YES];
   // [cell.mainView setTitle:model.buttonRight forState:UIControlStateNormal];
    
    
//    cell.mainLabel.layer.cornerRadius=10;
//    cell.mainLabel.layer.masksToBounds=YES;
//    [cell.mainLabel.layer setBorderColor:[UIColor blueColor].CGColor];
//    [cell.mainLabel.layer setBorderWidth:1];
//    [cell.mainLabel.layer setMasksToBounds:YES];
    
    
    NSString *str;
    if (indexPath.row == 0) {
        cell.timeFinish.hidden = 1;
        str = @"   OC，指的是output compare单片机相关的概念。输出比较的作用是用程序的方法在特定的时刻输出需要的电平，实现对外部电路的控制。详细资料可以见单片机里面的ETC模块。OC，Opera官方中文社区Operachina的简称。";
    } else if (indexPath.row == 1){
        cell.mainView.hidden = 1;
        str = nil;
    }else{
        str = @" OC兼职网(http://www.114oc.com)是一个真实可靠的兼职供求平台。我们的兼职信息都经过多重核查,兼职信息真实度高达98%。OC兼职网致力于为用户提供更安全";
    }
    cell.mainLabel.text = str;
    
   // cell.buttonRight.hidden = 1;
    
    
    
    
    
    
    
    return cell;
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



   
    
    
    
    
    
    
    









@end
