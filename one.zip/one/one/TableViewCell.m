//
//  TableViewCell.m
//  one
//
//  Created by  刘雅兰 on 17/10/23.
//  Copyright © 2017年  刘雅兰. All rights reserved.
//

#import "TableViewCell.h"

@implementation TableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    
    self=[super initWithStyle:style reuseIdentifier:reuseIdentifier];
    
    if (self) {
      
        CGFloat cellWidth=self.frame.size.width;
        CGFloat cellHeight=self.frame.size.height;
        
        self.titleLeft=[[UILabel alloc]initWithFrame:CGRectMake(cellWidth-300, cellHeight-5, 120, 30)];
        self.titleLeft.font=[UIFont fontWithName:@"Arial" size:19.0];
        [self addSubview:self.titleLeft];
        
        
        self.titleRight=[[UILabel alloc]initWithFrame:CGRectMake(700, 10, 120, 30)];
        [self addSubview:self.titleRight];
        
        
        self.timeBegin=[[UILabel alloc]initWithFrame:CGRectMake(cellWidth-300, 50, 250, 30)];
        self.timeBegin.font=[UIFont fontWithName:@"Arial" size:15.0];
        [self addSubview:self.timeBegin];
        
        
        self.timeFinish=[[UILabel alloc]initWithFrame:CGRectMake(cellWidth-300, 70, 250, 30)];
        self.timeFinish.font=[UIFont fontWithName:@"Arial" size:15.0];
        [self addSubview:self.timeFinish];
        

        self.buttonLeft=[[UIButton alloc]initWithFrame:CGRectMake(200, 50, 250, 50)];
        [self addSubview:self.buttonLeft];
        
        
        self.buttonRight=[[UIButton alloc]initWithFrame:CGRectMake(200, 50, 250, 50)];
        [self addSubview:self.buttonRight];
        
        
    }
    
    return self;
}



@end
